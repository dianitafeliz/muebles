import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directorio-admin',
  templateUrl: './directorio-admin.component.html',
  styleUrls: ['./directorio-admin.component.scss']
})
export class DirectorioAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
