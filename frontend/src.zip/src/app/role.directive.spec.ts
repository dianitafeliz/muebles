import { RoleDirective } from './role.directive';

describe('RoleDirective', () => {
  it('should create an instance', () => {
    const directive = new RoleDirective();
    expect(directive).toBeTruthy();
  });
});
