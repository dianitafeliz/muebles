export class Usuario{

    id!:BigInteger;
    email!:String;
    first_name!:String;
    second_name!:String;
    first_surname!:String;
    second_surname!:String;
    number!:String;
    password!:String;
    image_id!:Number;
    name!:String;
    sector_id!:Number;
    position!:String;
    area!:String;
    direction?:String;
}