export class Reaction{
    user_id!:Number;
    message_id!:Number;
}