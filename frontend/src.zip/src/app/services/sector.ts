export class Sector{
    position!:String;
    area!:String;
}