export interface LoginI{
    email:String;
    password:String;
}