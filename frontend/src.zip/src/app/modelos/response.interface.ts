export interface ResponseI{
    status:string;
    response:string;
}